This directory contains the implementation of the "common demo tasks".  These
are test tasks and demo tasks that are used by nearly all the demo applications.