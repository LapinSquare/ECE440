/* 
 * Project:     Project 1
 * File name:   main.c
 * Author:      Kim Huynh
 * Date:        9/7/20
 * Based on:    RD1
 *
 * Description: Pressing button 1 (BTN1) will turn on/ off LEDA on the PmodSTEP
 *              board. Pressing button 2 (BTN2) will turn on/ off LEDB on the 
 *              same board. vTaskDelay and vTaskDelete has been enabled in the
 *              FreeRTOSConfig file. 
 *
 * Notes:  Please press the buttons firmly. But not for too long.  
 *         Press it for too long, and it will blink a lot. 
 *         Don't bully the buttons. 
*******************************************************************************/

//Standard includes.
#include <plib.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "FreeRTOSConfig.h"

//Hardware settings.
#include "chipKIT_Pro_MX7.h"

//Hardware setup.
static void prvSetupHardware( void );

//Starter task and the tasks it will create.
static void vStarterTask( void *pvParameters );
static void vSendButtonTask( void *pvParameters ); //Sending task.
static void vToggleLEDTask( void *pvParameters );  //Receiver and toggle.

//Delay function. Just in case. 
void hw_msDelay(unsigned int mS);

//Queues buttons will use.
xQueueHandle xQueueBTN1; //Queue for BTN1
xQueueHandle xQueueBTN2; //Queue for BTN2

//Main function 
int main( void )
{
    //Setup hardware. 
    prvSetupHardware();		
    
    //Create starting task.
    xTaskCreate( vStarterTask, "Starting Task", configMINIMAL_STACK_SIZE,
                                    NULL, 3, NULL );

    //Start scheduler.
    vTaskStartScheduler();	

    //Should hopefully never get here. 
    return 0;
}  

//Creates 2 queues, 2 instances of a "SendButton" task, single "ToggleLED" task.
static void vStarterTask( void *pvParameters )
{
    //Create text parameters for button tasks. Ripped from EX2, FreeRTOS-Tasks.
    static const char *paramBTN1="BTN1";
    static const char *paramBTN2="BTN2";
    
    //Create queues.
    xQueueBTN1=xQueueCreate(5, sizeof(int)); 
    xQueueBTN2=xQueueCreate(5, sizeof(int));
    
    //Create tasks.
    if(xQueueBTN1!=NULL && xQueueBTN2!=NULL){

        //Numerical values don't work well as parameters, as a side note. 
        xTaskCreate( vSendButtonTask, "SendButton1 Task", configMINIMAL_STACK_SIZE,
                                        (void *)paramBTN1, 1, NULL );
        xTaskCreate( vSendButtonTask, "SendButton2 Task", configMINIMAL_STACK_SIZE,
                                        (void *)paramBTN2, 1, NULL );
        xTaskCreate( vToggleLEDTask, "ToggleLED Task", configMINIMAL_STACK_SIZE,
                                        NULL, 2, NULL );
    }
    else 
    {
        //Oops :0
    }
    vTaskDelete(NULL);
}  

//Task instance to send to queue. 
//First task will send to xQueueBTN1. Second will send to xQueueBTN2.
static void vSendButtonTask( void *pvParameters )
{ 
    //Delay variable.
    const portTickType xTicksToWait= 20/portTICK_RATE_MS;
    
    //Variable to determine which increment button is on. 
    unsigned int BTNCounter=0; //Not pushed yet.
    
    //Button variables to keep track if button was pressed or not. 
    int pressBTN1=0; //For BTN1
	int pressBTN2=0; //For BTN2
    
    //Determine status.
    portBASE_TYPE xStatus; 
    
    //Determine which task we are on.
    char *paramBTN=(char *)pvParameters;
    
    for( ;; ){
        if (paramBTN=="BTN1") //BTN1 task based on task parameter.
        {
            while(pressBTN1<=0){ //Poll for button press.
                pressBTN1=(PORTG & BTN1);
                hw_msDelay(20); //Debounce
            }
            if ((pressBTN1>0)||(PORTG & BTN1)) //If BTN1 is pressed. Double check.
            {
                BTNCounter++; //Signal that button has been pressed.
                xStatus=xQueueSendToBack(xQueueBTN1, &(BTNCounter), 0);
            }
        }
        
        else{ //Will probably be BTN2 task.
            while(pressBTN2<=0){ //Poll
                pressBTN2=(PORTG & BTN2);
                hw_msDelay(20); //Debounce
            }
            if ((pressBTN2>0)||(PORTG & BTN2)) //If BTN2 is pressed. Double check.
            {
                BTNCounter++;
                xStatus=xQueueSendToBack(xQueueBTN2, &(BTNCounter), 0); 
            }
        }

        //Reset buttons
        pressBTN1=0; 
        pressBTN2=0;
        
        //Give the other task a chance! :( 
        taskYIELD();
        
    }
}  

//Task that receives queues and toggles LEDs accordingly. 
static void vToggleLEDTask( void *pvParameters )
{ 
    //Received values from queues.
    int lReceivedValue1=0;
    int lReceivedValue2=0;
    
    //Statuses. 
    portBASE_TYPE xStatus1;
    portBASE_TYPE xStatus2;
    
    //Delay. 
    const portTickType xTicksToWait= 20/portTICK_RATE_MS;
    
    for( ;; )
    {
        //Receive statuses from all queues. 
        xStatus1=xQueueReceive(xQueueBTN1, &(lReceivedValue1), xTicksToWait);
        xStatus2=xQueueReceive(xQueueBTN2, &(lReceivedValue2), xTicksToWait);
        
        //Notes: I was planning on printing which increment the button was 
        //pressed, but I don't believe that is necessary to show right now 
        //with vPrintString being unwieldy. 
        
        //Is there something in there? Turn on/off LEDA.
        if (xStatus1==pdPASS){ 
            LATBINV=LEDA; 
            lReceivedValue1=0; //Reset value.
        }
        
        //For LEDB.
        if (xStatus2==pdPASS){ 
            LATBINV=LEDB; 
            lReceivedValue2=0;
        }
       
        vTaskDelay(xTicksToWait); //Give some extra time. 
    }
}  

//Setup hardware.
static void prvSetupHardware( void )
{
    chipKIT_PRO_MX7_Setup();

    //Set up input/ output.
    PORTSetPinsDigitalIn(IOPORT_G, BTN1|BTN2);
    PORTSetPinsDigitalOut(IOPORT_B, SM_LEDS);
    LATBCLR = SM_LEDS;
    LATGCLR = BTN1|BTN2;
    
    //Multi-vector interrupts. Relic of RD1.
    INTConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);  
    INTEnableInterrupts();   
    portDISABLE_INTERRUPTS();
} 

//For stack overflow.  
void vApplicationStackOverflowHook( void )
{
	for( ;; );
} 

//For exceptions.
void _general_exception_handler( unsigned long ulCause, unsigned long ulStatus )
{
    for( ;; );
} 

//Delays a certain amount of ms. 
//Ripped off straight from lab2, ECE341. 
void hw_msDelay(unsigned int mS) { 
    unsigned int tWait, tStart; 
    tStart=ReadCoreTimer(); // Read core timer count - SW Start breakpoint
    tWait= (CORE_MS_TICK_RATE * mS); // Set time to wait  
    while((ReadCoreTimer() - tStart) < tWait);  // Wait for the time to pass
 } 

/*--------------------------End of main.c  -----------------------------------*/