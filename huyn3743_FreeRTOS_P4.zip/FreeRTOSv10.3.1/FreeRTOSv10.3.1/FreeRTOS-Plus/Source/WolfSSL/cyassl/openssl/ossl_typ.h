/* ossl_typ.h for openssl */

#include <wolfssl/openssl/ossl_typ.h>
